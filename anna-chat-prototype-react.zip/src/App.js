import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Hei, olen Anna 👩</h1>
      <p>Kiva tutustua! Kysy mitä tahansa – vastaan mielelläni flirttaillen ja syvällisesti 😉</p>
    </div>
  );
}

export default App;